<?php
// Includes
require 'view/load.php';
require 'model/model.php';
require 'controller/controller.php';
// Initialise by creating a new controller instance (or object)
new Controller();
?>