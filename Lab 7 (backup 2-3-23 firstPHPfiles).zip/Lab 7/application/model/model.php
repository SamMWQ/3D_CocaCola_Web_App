<?php
class Model {
    // Method to simulate the model data
    public function model3D_info() {
        // Simulate the model's data
        return array(
            'model_1' => 'Coke Can 3D Image 1',
            'model_2' => 'Coke Can 3D Image 2',
            'model_3' => 'Sprite Bottle 3D Image 1',
            'model_4' => 'Sprite Bottle 3D Image 2',
            'model_5' => 'Dr Pepper Cup 3D Image 1',
            'model_6' => 'Dr Pepper Cup 3D Image 2'
        );
    }
}
?>