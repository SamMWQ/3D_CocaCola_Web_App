<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Hello world!</title>
</head>
<p>HTML says Hello world</p>
<script type="text/javascript">
    document.write('<p>JavaScript says Hello world</p>');
</script>
<?php
echo "<p>PHP says Hello world</p>";
?>

<body>
</body>

</html>